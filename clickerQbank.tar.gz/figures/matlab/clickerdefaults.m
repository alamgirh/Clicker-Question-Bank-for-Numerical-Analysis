set( 0, 'DefaultTextFontName',  'Arial' );
set( 0, 'DefaultAxesFontName',  'Arial' );
set( 0, 'DefaultTextFontSize',   20 );
set( 0, 'DefaultAxesFontSize',   20 );
set( 0, 'DefaultLineLineWidth',  2 ); 
set( 0, 'DefaultLineMarkerSize', 10 ); 
myblue  = [ 0.0000, 0.4470, 0.7410 ]; 
mygreen = [ 0.4660, 0.6740, 0.1880 ];
mygrey  = [ 0.8, 0.8, 0.8 ];

